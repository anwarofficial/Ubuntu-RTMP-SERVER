
/*
 * Copyright (C) Roman Arutyunyan
 */


#ifndef _NGX_RTMP_VERSION_H_INCLUDED_
#define _NGX_RTMP_VERSION_H_INCLUDED_


#define nginx_rtmp_version  1002002
#define NGINX_RTMP_VERSION  "1.2.2-dev"


#endif /* _NGX_RTMP_VERSION_H_INCLUDED_ */
